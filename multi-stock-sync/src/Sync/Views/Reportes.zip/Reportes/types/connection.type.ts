export interface Connection {
  //Creamos la interfaz Connection para el cliente
  client_id: string; // ID del cliente
  nickname: string; // Apodo del cliente
}
