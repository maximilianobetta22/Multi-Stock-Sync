import React, { useState, useEffect } from "react";
import {
  Modal,
  Form,
  Input,
  InputNumber,
  Select,
  Switch,
  Row,
  Col,
  Card,
  Alert,
  Space,
  Button,
  Upload,
  message,
  Divider,
  Tag,
  Image,
} from "antd";
import { PlusOutlined, DeleteOutlined, LinkOutlined } from "@ant-design/icons";
import axios from "axios";

const { TextArea } = Input;
const { Option } = Select;

interface WooCommerceCategory {
  id: number;
  name: string;
  slug: string;
  parent: number;
  description: string;
  count: number;
}

interface Props {
  visible: boolean;
  onClose: () => void;
  onSave: (values: any) => Promise<void>;
  loading: boolean;
}

const CrearProductoWooModal: React.FC<Props> = ({
  visible,
  onClose,
  onSave,
  loading,
}) => {
  const [form] = Form.useForm();
  const [categories, setCategories] = useState<WooCommerceCategory[]>([]);
  const [loadingCategories, setLoadingCategories] = useState(false);
  const [images, setImages] = useState<string[]>([]);

  // Obtener Store ID mapeado
  const getStoreId = () => {
    const conexion = JSON.parse(localStorage.getItem("conexionSeleccionada") || "{}");
    // Mapeo simple basado en el servicio existente
    const STORE_MAPPING: Record<string, number> = {
      OFERTASIMPERDIBLESCHILE: 1,
      ofertasimperdibles: 1,
      LENCERIAONLINE: 2,
      lenceriaonline: 2,
      CRAZYFAMILY: 3,
      crazyfamily: 3,
      COMERCIALIZADORAABIZICL: 4,
      ABIZI: 4,
      abizi: 4,
    };

    return STORE_MAPPING[conexion.nickname?.toLowerCase()] ||
           STORE_MAPPING[conexion.nickname?.toUpperCase()] ||
           STORE_MAPPING[conexion.client_id] ||
           1; // Default fallback
  };

  // Cargar categorías cuando se abre el modal
  const loadCategories = async () => {
    const storeId = getStoreId();
    setLoadingCategories(true);
    
    try {
      const token = localStorage.getItem("access_token") || localStorage.getItem("token");
      const response = await axios.get(
        `${import.meta.env.VITE_API_URL}/woocommerce/woo/${storeId}/categories`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Accept': 'application/json',
          },
          params: {
            per_page: 100, // Obtener todas las categorías
            orderby: 'name',
            order: 'asc',
          }
        }
      );

      console.log("📦 Categorías cargadas:", response.data);
      
      if (response.data.categories) {
        setCategories(response.data.categories);
      }
    } catch (error: any) {
      console.error("❌ Error al cargar categorías:", error);
      message.error("Error al cargar las categorías de WooCommerce");
    } finally {
      setLoadingCategories(false);
    }
  };

  // Cargar categorías cuando se abre el modal
  useEffect(() => {
    if (visible) {
      loadCategories();
    }
  }, [visible]);

  // Agregar imagen por URL
  const handleAddImageUrl = () => {
    const url = prompt("Ingresa la URL de la imagen:");
    if (url && url.trim()) {
      // Validar que sea una URL válida
      try {
        new URL(url);
        setImages(prev => [...prev, url.trim()]);
        message.success("Imagen agregada correctamente");
      } catch {
        message.error("URL de imagen no válida");
      }
    }
  };

  // Eliminar imagen
  const handleRemoveImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      
      // Validaciones básicas
      if (!values.name || values.name.trim() === '') {
        message.error('El nombre del producto es obligatorio');
        return;
      }

      if (!values.sku || values.sku.trim() === '') {
        message.error('El SKU del producto es obligatorio');
        return;
      }

      if (!values.regular_price || values.regular_price <= 0) {
        message.error('El precio del producto debe ser mayor a 0');
        return;
      }

      // Función helper para convertir a número o null
      const toNumberOrNull = (value: any) => {
        if (value === null || value === undefined || value === '') return null;
        const num = parseFloat(value);
        return isNaN(num) ? null : num;
      };

      // Función helper para convertir a string o null
      const toStringOrNull = (value: any) => {
        if (value === null || value === undefined || value === '') return null;
        return value.toString();
      };
      
      // Preparar imágenes para WooCommerce
      const productImages = images.map((url, index) => ({
        src: url,
        alt: `${values.name} - Imagen ${index + 1}`,
        position: index
      }));

      // Preparar categorías seleccionadas
      const selectedCategories = values.categories ? 
        values.categories.map((catId: number) => ({ id: catId })) : [];
      
      // Limpiar y estructurar los datos según lo que espera WooCommerce/Laravel
      const productData = {
        name: values.name.trim(),
        type: values.type || "simple",
        regular_price: toNumberOrNull(values.regular_price),
        sale_price: toNumberOrNull(values.sale_price),
        description: values.description?.trim() || "",
        short_description: values.short_description?.trim() || "",
        sku: values.sku.trim(),
        manage_stock: Boolean(values.manage_stock),
        stock_quantity: values.manage_stock ? (values.stock_quantity || 0) : null,
        stock_status: values.stock_status || "instock",
        weight: toStringOrNull(values.weight),
        dimensions: {
          length: toStringOrNull(values.dimensions?.length),
          width: toStringOrNull(values.dimensions?.width),
          height: toStringOrNull(values.dimensions?.height),
        },
        status: values.status || "publish",
        featured: Boolean(values.featured),
        catalog_visibility: values.catalog_visibility || "visible",
        virtual: Boolean(values.virtual),
        downloadable: Boolean(values.downloadable),
        reviews_allowed: Boolean(values.reviews_allowed !== false),
        tax_status: values.tax_status || "taxable",
        categories: selectedCategories,
        tags: [],
        images: productImages,
      };

      console.log("📋 Datos a enviar:", productData);
      
      await onSave(productData);
      
      // Limpiar formulario y cerrar modal
      form.resetFields();
      setImages([]);
      
    } catch (error) {
      console.error("❌ Error al validar formulario:", error);
    }
  };

  const handleCancel = () => {
    form.resetFields();
    setImages([]);
    onClose();
  };

  return (
    <Modal
      title="Crear Nuevo Producto WooCommerce"
      open={visible}
      onCancel={handleCancel}
      onOk={handleOk}
      confirmLoading={loading}
      width={1000}
      style={{ top: 20 }}
      okText="Crear Producto"
      cancelText="Cancelar"
      destroyOnClose={true}
    >
      <Alert
        message="Información importante"
        description="Completa todos los campos obligatorios marcados con *. Las imágenes se pueden agregar por URL."
        type="info"
        showIcon
        style={{ marginBottom: 16 }}
      />

      <Form
        form={form}
        layout="vertical"
        initialValues={{
          type: "simple",
          status: "publish",
          stock_status: "instock",
          catalog_visibility: "visible",
          tax_status: "taxable",
          manage_stock: true,
          featured: false,
          virtual: false,
          downloadable: false,
          reviews_allowed: true,
          stock_quantity: 1,
          regular_price: 0,
        }}
      >
        {/* Información básica */}
        <Card title="Información Básica" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={24}>
              <Form.Item
                name="name"
                label="Nombre del Producto *"
                rules={[
                  { required: true, message: "El nombre es obligatorio" },
                  { min: 3, message: "El nombre debe tener al menos 3 caracteres" }
                ]}
              >
                <Input placeholder="Ej: Camiseta de algodón azul" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="type" label="Tipo de Producto">
                <Select>
                  <Option value="simple">Simple</Option>
                  <Option value="grouped">Agrupado</Option>
                  <Option value="external">Externo</Option>
                  <Option value="variable">Variable</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item 
                name="sku" 
                label="SKU *"
                rules={[
                  { required: true, message: "El SKU es obligatorio" },
                  { min: 3, message: "El SKU debe tener al menos 3 caracteres" }
                ]}
              >
                <Input placeholder="Código único del producto (ej: CAM-001)" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={24}>
              <Form.Item name="short_description" label="Descripción Corta">
                <TextArea
                  rows={2}
                  placeholder="Descripción breve que aparece en el listado"
                  maxLength={160}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={24}>
              <Form.Item name="description" label="Descripción Completa">
                <TextArea
                  rows={4}
                  placeholder="Descripción detallada del producto"
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Precios */}
        <Card title="Precios" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="regular_price"
                label="Precio Regular *"
                rules={[
                  { required: true, message: "El precio es obligatorio" },
                  { type: 'number', min: 0, message: "El precio debe ser mayor a 0" }
                ]}
              >
                <InputNumber
                  min={0}
                  style={{ width: "100%" }}
                  placeholder="Ej: 19990"
                  formatter={value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={value => value!.replace(/\$\s?|(,*)/g, '')}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="sale_price" label="Precio de Oferta">
                <InputNumber
                  min={0}
                  style={{ width: "100%" }}
                  placeholder="Ej: 15990"
                  formatter={value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={value => value!.replace(/\$\s?|(,*)/g, '')}
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Categorías */}
        <Card title="Categorización" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={24}>
              <Form.Item name="categories" label="Categorías">
                <Select
                  mode="multiple"
                  placeholder="Selecciona las categorías del producto"
                  loading={loadingCategories}
                  showSearch
                  optionFilterProp="children"
                  notFoundContent={loadingCategories ? "Cargando..." : "No hay categorías"}
                >
                  {categories.map((category) => (
                    <Option key={category.id} value={category.id}>
                      {category.name} {category.count > 0 && `(${category.count} productos)`}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Imágenes */}
        <Card title="Imágenes del Producto" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={24}>
              <Space direction="vertical" style={{ width: "100%" }}>
                <Button 
                  type="dashed" 
                  icon={<LinkOutlined />} 
                  onClick={handleAddImageUrl}
                  style={{ width: "100%" }}
                >
                  Agregar imagen por URL
                </Button>
                
                {images.length > 0 && (
                  <div>
                    <Divider orientation="left">Imágenes agregadas ({images.length})</Divider>
                    <Row gutter={[8, 8]}>
                      {images.map((imageUrl, index) => (
                        <Col key={index} span={6}>
                          <Card
                            size="small"
                            cover={
                              <Image
                                src={imageUrl}
                                alt={`Producto imagen ${index + 1}`}
                                style={{ height: 120, objectFit: "cover" }}
                                fallback="/placeholder.svg"
                              />
                            }
                            actions={[
                              <Button
                                type="text"
                                danger
                                size="small"
                                icon={<DeleteOutlined />}
                                onClick={() => handleRemoveImage(index)}
                              >
                                Eliminar
                              </Button>
                            ]}
                          >
                            <Card.Meta
                              description={
                                <Tag color="blue">Imagen {index + 1}</Tag>
                              }
                            />
                          </Card>
                        </Col>
                      ))}
                    </Row>
                  </div>
                )}
              </Space>
            </Col>
          </Row>
        </Card>

        {/* Inventario */}
        <Card title="Inventario" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="manage_stock" valuePropName="checked">
                <Switch 
                  checkedChildren="Gestionar stock" 
                  unCheckedChildren="No gestionar stock"
                  onChange={(checked) => {
                    if (!checked) {
                      form.setFieldsValue({ stock_quantity: null });
                    }
                  }}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item 
                name="stock_quantity" 
                label="Cantidad en Stock"
                dependencies={['manage_stock']}
                rules={[
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (getFieldValue('manage_stock') && (!value || value <= 0)) {
                        return Promise.reject(new Error('La cantidad debe ser mayor a 0 si gestionas stock'));
                      }
                      return Promise.resolve();
                    },
                  }),
                ]}
              >
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  disabled={!Form.useWatch('manage_stock', form)}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="stock_status" label="Estado del Stock">
                <Select>
                  <Option value="instock">En Stock</Option>
                  <Option value="outofstock">Sin Stock</Option>
                  <Option value="onbackorder">En Espera</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Dimensiones y peso */}
        <Card title="Envío" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={6}>
              <Form.Item name="weight" label="Peso (kg)">
                <InputNumber 
                  min={0} 
                  step={0.1} 
                  style={{ width: "100%" }}
                  placeholder="0.5"
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name={["dimensions", "length"]} label="Largo (cm)">
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  placeholder="20"
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name={["dimensions", "width"]} label="Ancho (cm)">
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  placeholder="15"
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name={["dimensions", "height"]} label="Alto (cm)">
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  placeholder="10"
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Configuración */}
        <Card title="Configuración" size="small">
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="status" label="Estado">
                <Select>
                  <Option value="publish">Publicado</Option>
                  <Option value="draft">Borrador</Option>
                  <Option value="pending">Pendiente</Option>
                  <Option value="private">Privado</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="catalog_visibility" label="Visibilidad">
                <Select>
                  <Option value="visible">Visible</Option>
                  <Option value="catalog">Solo Catálogo</Option>
                  <Option value="search">Solo Búsqueda</Option>
                  <Option value="hidden">Oculto</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="tax_status" label="Estado de Impuestos">
                <Select>
                  <Option value="taxable">Gravable</Option>
                  <Option value="shipping">Solo Envío</Option>
                  <Option value="none">Ninguno</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16} style={{ marginTop: 16 }}>
            <Col span={8}>
              <Form.Item name="featured" valuePropName="checked">
                <Switch checkedChildren="Destacado" unCheckedChildren="Normal" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="virtual" valuePropName="checked">
                <Switch checkedChildren="Virtual" unCheckedChildren="Físico" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="reviews_allowed" valuePropName="checked">
                <Switch checkedChildren="Permitir reseñas" unCheckedChildren="Sin reseñas" />
              </Form.Item>
            </Col>
          </Row>
        </Card>
      </Form>
    </Modal>
  );
};

export default CrearProductoWooModal;