import React from "react";
import {
  Modal,
  Form,
  Input,
  InputNumber,
  Select,
  Switch,
  Row,
  Col,
  Card,
  Alert,
  Space,
} from "antd";

const { TextArea } = Input;
const { Option } = Select;

interface Props {
  visible: boolean;
  onClose: () => void;
  onSave: (values: any) => Promise<void>;
  loading: boolean;
}

const CrearProductoWooModal: React.FC<Props> = ({
  visible,
  onClose,
  onSave,
  loading,
}) => {
  const [form] = Form.useForm();

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      
      // Generar SKU automático si no se proporciona
      const sku = values.sku || `WOO-${Date.now()}`;
      
      // Función helper para convertir a número o null
      const toNumberOrNull = (value: any) => {
        if (value === null || value === undefined || value === '') return null;
        const num = parseFloat(value);
        return isNaN(num) ? null : num;
      };

      // Función helper para convertir a string o null
      const toStringOrNull = (value: any) => {
        if (value === null || value === undefined || value === '') return null;
        return value.toString();
      };
      
      // Limpiar y estructurar los datos según lo que espera WooCommerce/Laravel
      const productData = {
        name: values.name.trim(),
        type: values.type || "simple",
        regular_price: toNumberOrNull(values.regular_price), // Número, no string
        sale_price: toNumberOrNull(values.sale_price), // Número o null, no string vacío
        description: values.description?.trim() || "",
        short_description: values.short_description?.trim() || "",
        sku: sku.trim(),
        manage_stock: Boolean(values.manage_stock),
        stock_quantity: values.manage_stock ? (values.stock_quantity || 0) : null,
        stock_status: values.stock_status || "instock",
        weight: toStringOrNull(values.weight), // String o null
        dimensions: {
          length: toStringOrNull(values.dimensions?.length), // String o null
          width: toStringOrNull(values.dimensions?.width),   // String o null
          height: toStringOrNull(values.dimensions?.height), // String o null
        },
        status: values.status || "publish",
        featured: Boolean(values.featured),
        catalog_visibility: values.catalog_visibility || "visible",
        virtual: Boolean(values.virtual),
        downloadable: Boolean(values.downloadable),
        reviews_allowed: Boolean(values.reviews_allowed !== false),
        tax_status: values.tax_status || "taxable",
        // Categorías por defecto si no se especifican
        categories: [],
        tags: [],
        images: [],
      };

      console.log("📋 Datos a enviar:", productData);
      console.log("🔍 Tipos de datos:");
      console.log("- regular_price:", typeof productData.regular_price, productData.regular_price);
      console.log("- sale_price:", typeof productData.sale_price, productData.sale_price);
      console.log("- weight:", typeof productData.weight, productData.weight);
      console.log("- dimensions:", productData.dimensions);
      
      await onSave(productData);
      form.resetFields();
    } catch (error) {
      console.error("❌ Error al validar formulario:", error);
    }
  };

  const handleCancel = () => {
    form.resetFields();
    onClose();
  };

  // Generar SKU automático basado en el nombre
  const generateSKU = () => {
    const name = form.getFieldValue('name') || '';
    if (name) {
      const sku = `WOO-${name.replace(/\s+/g, '-').toUpperCase().slice(0, 10)}-${Date.now().toString().slice(-4)}`;
      form.setFieldsValue({ sku });
    }
  };

  return (
    <Modal
      title="Crear Nuevo Producto WooCommerce"
      open={visible}
      onCancel={handleCancel}
      onOk={handleOk}
      confirmLoading={loading}
      width={900}
      style={{ top: 20 }}
      okText="Crear Producto"
      cancelText="Cancelar"
      destroyOnClose={true}
    >
      <Alert
        message="Información importante"
        description="Todos los campos marcados con * son obligatorios. El SKU se generará automáticamente si no lo especificas."
        type="info"
        showIcon
        style={{ marginBottom: 16 }}
      />

      <Form
        form={form}
        layout="vertical"
        initialValues={{
          type: "simple",
          status: "publish",
          stock_status: "instock",
          catalog_visibility: "visible",
          tax_status: "taxable",
          manage_stock: true,
          featured: false,
          virtual: false,
          downloadable: false,
          reviews_allowed: true,
          stock_quantity: 1,
          regular_price: 0,
        }}
      >
        {/* Información básica */}
        <Card title="Información Básica" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={24}>
              <Form.Item
                name="name"
                label="Nombre del Producto *"
                rules={[
                  { required: true, message: "El nombre es obligatorio" },
                  { min: 3, message: "El nombre debe tener al menos 3 caracteres" }
                ]}
              >
                <Input 
                  placeholder="Ej: Camiseta de algodón azul" 
                  onChange={() => {
                    // Auto-generar SKU si no existe
                    setTimeout(() => {
                      if (!form.getFieldValue('sku')) {
                        generateSKU();
                      }
                    }, 100);
                  }}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="type" label="Tipo de Producto">
                <Select>
                  <Option value="simple">Simple</Option>
                  <Option value="grouped">Agrupado</Option>
                  <Option value="external">Externo</Option>
                  <Option value="variable">Variable</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item 
                name="sku" 
                label="SKU *"
                rules={[
                  { required: true, message: "El SKU es obligatorio" },
                  { min: 3, message: "El SKU debe tener al menos 3 caracteres" }
                ]}
              >
                <Input 
                  placeholder="Código único del producto"
                  addonAfter={
                    <span 
                      style={{ cursor: 'pointer', color: '#1890ff' }}
                      onClick={generateSKU}
                    >
                      Auto
                    </span>
                  }
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={24}>
              <Form.Item name="short_description" label="Descripción Corta">
                <TextArea
                  rows={2}
                  placeholder="Descripción breve que aparece en el listado"
                  maxLength={160}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={24}>
              <Form.Item name="description" label="Descripción Completa">
                <TextArea
                  rows={4}
                  placeholder="Descripción detallada del producto"
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Precios */}
        <Card title="Precios" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="regular_price"
                label="Precio Regular *"
                rules={[
                  { required: true, message: "El precio es obligatorio" },
                  { type: 'number', min: 0, message: "El precio debe ser mayor a 0" }
                ]}
              >
                <InputNumber
                  min={0}
                  style={{ width: "100%" }}
                  placeholder="Ej: 19990"
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="sale_price" label="Precio de Oferta">
                <InputNumber
                  min={0}
                  style={{ width: "100%" }}
                  placeholder="Ej: 15990"
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Inventario */}
        <Card title="Inventario" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="manage_stock" valuePropName="checked">
                <Switch 
                  checkedChildren="Gestionar stock" 
                  unCheckedChildren="No gestionar stock"
                  onChange={(checked) => {
                    if (!checked) {
                      form.setFieldsValue({ stock_quantity: null });
                    }
                  }}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item 
                name="stock_quantity" 
                label="Cantidad en Stock"
                dependencies={['manage_stock']}
                rules={[
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (getFieldValue('manage_stock') && (!value || value <= 0)) {
                        return Promise.reject(new Error('La cantidad debe ser mayor a 0 si gestionas stock'));
                      }
                      return Promise.resolve();
                    },
                  }),
                ]}
              >
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  disabled={!Form.useWatch('manage_stock', form)}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="stock_status" label="Estado del Stock">
                <Select>
                  <Option value="instock">En Stock</Option>
                  <Option value="outofstock">Sin Stock</Option>
                  <Option value="onbackorder">En Espera</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Dimensiones y peso */}
        <Card title="Envío" size="small" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={6}>
              <Form.Item name="weight" label="Peso (kg)">
                <InputNumber 
                  min={0} 
                  step={0.1} 
                  style={{ width: "100%" }}
                  placeholder="0.5"
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name={["dimensions", "length"]} label="Largo (cm)">
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  placeholder="20"
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name={["dimensions", "width"]} label="Ancho (cm)">
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  placeholder="15"
                />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name={["dimensions", "height"]} label="Alto (cm)">
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }}
                  placeholder="10"
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Configuración */}
        <Card title="Configuración" size="small">
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="status" label="Estado">
                <Select>
                  <Option value="publish">Publicado</Option>
                  <Option value="draft">Borrador</Option>
                  <Option value="pending">Pendiente</Option>
                  <Option value="private">Privado</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="catalog_visibility" label="Visibilidad">
                <Select>
                  <Option value="visible">Visible</Option>
                  <Option value="catalog">Solo Catálogo</Option>
                  <Option value="search">Solo Búsqueda</Option>
                  <Option value="hidden">Oculto</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="tax_status" label="Estado de Impuestos">
                <Select>
                  <Option value="taxable">Gravable</Option>
                  <Option value="shipping">Solo Envío</Option>
                  <Option value="none">Ninguno</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16} style={{ marginTop: 16 }}>
            <Col span={8}>
              <Form.Item name="featured" valuePropName="checked">
                <Switch checkedChildren="Destacado" unCheckedChildren="Normal" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="virtual" valuePropName="checked">
                <Switch checkedChildren="Virtual" unCheckedChildren="Físico" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="reviews_allowed" valuePropName="checked">
                <Switch checkedChildren="Permitir reseñas" unCheckedChildren="Sin reseñas" />
              </Form.Item>
            </Col>
          </Row>
        </Card>
      </Form>
    </Modal>
  );
};

export default CrearProductoWooModal;